export class UserProfile {
    userId: number;
    userName: string;
    
}