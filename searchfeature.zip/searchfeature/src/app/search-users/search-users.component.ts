import { Component, OnInit } from '@angular/core';
import { UserProfile } from './userprofile';
import { UserprofileService } from './userprofile.service';

@Component({
  selector: 'app-search-users',
  templateUrl: './search-users.component.html',
  styleUrls: ['./search-users.component.css']
})
export class SearchUsersComponent implements OnInit {

  userName: string;
  _listFilter:string;
  users:UserProfile[]=[];
  filteredUsers:UserProfile[];
  errorMessage:string;
  user:UserProfile;
  flag:boolean=false;
  public pageTitle: string = 'searchuser';

  constructor(private userService : UserprofileService) { }

  ngOnInit() {
    this.userService.getUsers().subscribe(users=> {
      this.users=users;
  },
  error=>this.errorMessage=<any>error
  );

  }

  
  get listFilter():string {
    return this._listFilter;

}
set listFilter(value:string)
{
    this._listFilter=value;
    this.userName=value
    this.filteredUsers=this.listFilter?this.performFilter(this.listFilter):null;
}


performFilter(filterBy:string): UserProfile[]
{
    filterBy=filterBy.toLocaleLowerCase();
    return this.users.filter((user:UserProfile)=>
    user.userName.toLocaleLowerCase().indexOf(filterBy)!==-1
    );
}

private showUser(user : UserProfile){
  this.flag=true;
  this.user=user;
  UserprofileService.users=user;
}




}
