import { Component, OnInit } from '@angular/core';
import { UserprofileService } from '../search-users/userprofile.service';
import { UserProfile } from '../search-users/userprofile';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  public pageTitle: string = 'showpage';
  


 

  constructor() { }

  ngOnInit() {
  }

}
