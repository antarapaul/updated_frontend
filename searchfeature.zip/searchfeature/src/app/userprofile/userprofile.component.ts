import { Component, OnInit } from '@angular/core';
import { UserprofileService } from '../search-users/userprofile.service';
import { UserProfile } from '../search-users/userprofile';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  public pageTitle: string = 'showuser';
  public userName: string;
  public userId: number;


 

  constructor() { }

  ngOnInit() {
    this.userName=UserprofileService.users.userName;
    this.userId=UserprofileService.users.userId;

    }

}
