import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchGroupsComponent } from './search-groups/search-groups.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { SearchUsersComponent } from './search-users/search-users.component';
import { RouterModule, Routes } from '../../node_modules/@angular/router';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'showpage/:name', component: UserprofileComponent},
  {path:'searchuser', component: SearchUsersComponent},
  {path:'searchgroup', component: SearchGroupsComponent}
  

];
@NgModule({
  declarations: [
    AppComponent,
    SearchGroupsComponent,
    SearchUsersComponent,
    UserprofileComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes
    
      
        /*  path: 'app-userprofile',
         component: UserprofileComponent */
      
   )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


