import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupprofileComponent } from './groupprofile.component';

describe('GroupprofileComponent', () => {
  let component: GroupprofileComponent;
  let fixture: ComponentFixture<GroupprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
