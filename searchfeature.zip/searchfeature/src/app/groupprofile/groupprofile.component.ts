import { Component, OnInit } from '@angular/core';
import { GroupsService } from '../search-groups/groups.service';

@Component({
  selector: 'app-groupprofile',
  templateUrl: './groupprofile.component.html',
  styleUrls: ['./groupprofile.component.css']
})
export class GroupprofileComponent implements OnInit {

  public pageTitle: string = 'showgroup';
  public groupName: string;
  public groupAdmin: string;
  public description: string;
  public groupId: number;


  



  constructor() { }

  ngOnInit() {

    this.groupName=GroupsService.groups.groupName;
    this.groupId=GroupsService.groups.groupId;
    this.description=GroupsService.groups.description;
    this.groupAdmin=GroupsService.groups.groupAdmin;
    


  }

}
