import { Component, OnInit } from '@angular/core';
import { Groups } from './groups';
import { GroupsService } from './groups.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-search-groups',
  templateUrl: './search-groups.component.html',
  styleUrls: ['./search-groups.component.css']
})
export class SearchGroupsComponent implements OnInit {

  groupName: string;
  _listFilter:string;
  groups:Groups[]=[];
  filteredGroups:Groups[];
  errorMessage:string;
  group:Groups;
  flag:boolean=false;
  public pageTitle: string = 'searchgroup';
 

  constructor(private dataService: GroupsService,private router: Router) {  }

  ngOnInit() {

    this.dataService.getGroups().subscribe(groups=> {
      this.groups=groups;
      // this.filteredGroups=this.groups;
     
      //console.log(this.groups)
  },
  error=>this.errorMessage=<any>error
  );

  }

  get listFilter():string {
    return this._listFilter;

}
set listFilter(value:string)
{
    this._listFilter=value;
    this.groupName=value
    this.filteredGroups=this.listFilter?this.performFilter(this.listFilter):null;
}


performFilter(filterBy:string): Groups[]
{
    filterBy=filterBy.toLocaleLowerCase();
    return this.groups.filter((group:Groups)=>
    group.groupName.toLocaleLowerCase().indexOf(filterBy)!==-1
    );
}



  private searchGroups(){
    this.dataService.getGroupsByName(this._listFilter).subscribe(groups=>this.groups=groups)
  }
 private showGroup(group:Groups){
  this.group=group;
  this.flag=true;
 }

  onSelect(group){
this.router.navigate(['/show',group.groupName])
  }

  onSubmit() {
    this.searchGroups();
  }



}
